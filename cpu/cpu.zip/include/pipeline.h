#ifndef CNN_PIPELINE_H
#define CNN_PIPELINE_H

// opencv
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>


#endif //CNN_PIPELINE_H
